import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Its Ready Pro',
      theme: ThemeData(primarySwatch: Colors.orange),
      home: AuthWrapper(),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (snap.hasData) return HomePage();
        return LoginPage();
      },
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser!;
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (!snap.data!.exists) return LoginPage();
        String role = (snap.data!.data() as Map<String, dynamic>)['role'] ?? 'customer';
        if (role == 'restaurant') return RestaurantHome();
        if (role == 'driver') return DriverHome();
        return CustomerHome();
      },
    );
  }
}

class LoginPage extends StatefulWidget { @override _LoginPageState createState() => _LoginPageState(); }
class _LoginPageState extends State<LoginPage> {
  final emailCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  String err = '';
  bool loading = false;
  login() async {
    setState(() { loading = true; err = ''; });
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: emailCtrl.text.trim(), password: passCtrl.text.trim());
    } catch (e) { setState(() { err = e.toString(); }); }
    setState(() { loading = false; });
  }
  @override Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Colors.orange[50], body: Center(child: SingleChildScrollView(padding: EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Text('Its Ready Pro', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.orange)),
      SizedBox(height: 10), Text('مرحبا - تسجيل الدخول', style: TextStyle(fontSize: 18)),
      SizedBox(height: 20),
      TextField(controller: emailCtrl, decoration: InputDecoration(labelText: 'الايميل', border: OutlineInputBorder(), prefixIcon: Icon(Icons.email))),
      SizedBox(height: 12),
      TextField(controller: passCtrl, obscureText: true, decoration: InputDecoration(labelText: 'كلمة السر', border: OutlineInputBorder(), prefixIcon: Icon(Icons.lock))),
      SizedBox(height: 12),
      if (err != '') Text(err, style: TextStyle(color: Colors.red)),
      SizedBox(height: 12),
      loading ? CircularProgressIndicator() : ElevatedButton(onPressed: login, style: ElevatedButton.styleFrom(backgroundColor: Colors.orange, minimumSize: Size(double.infinity, 50)), child: Text('دخول', style: TextStyle(fontSize: 18, color: Colors.white))),
      TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => RegisterPage())), child: Text('ما عندكش حساب؟ سجل دابا')),
    ]))));
  }
}

class RegisterPage extends StatefulWidget { @override _RegisterPageState createState() => _RegisterPageState(); }
class _RegisterPageState extends State<RegisterPage> {
  final nameCtrl = TextEditingController(); final emailCtrl = TextEditingController(); final passCtrl = TextEditingController();
  String role = 'customer'; String err = ''; bool loading = false;
  register() async {
    setState(() { loading = true; err = ''; });
    try {
      var cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: emailCtrl.text.trim(), password: passCtrl.text.trim());
      await FirebaseFirestore.instance.collection('users').doc(cred.user!.uid).set({'name': nameCtrl.text.trim(), 'email': emailCtrl.text.trim(), 'role': role, 'createdAt': FieldValue.serverTimestamp()});
      Navigator.pop(context);
    } catch (e) { setState(() { err = e.toString(); }); }
    setState(() { loading = false; });
  }
  @override Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('انشاء حساب'), backgroundColor: Colors.orange), body: SingleChildScrollView(padding: EdgeInsets.all(24), child: Column(children: [
      TextField(controller: nameCtrl, decoration: InputDecoration(labelText: 'الاسم', border: OutlineInputBorder())),
      SizedBox(height: 12),
      TextField(controller: emailCtrl, decoration: InputDecoration(labelText: 'الايميل', border: OutlineInputBorder())),
      SizedBox(height: 12),
      TextField(controller: passCtrl, obscureText: true, decoration: InputDecoration(labelText: 'كلمة السر', border: OutlineInputBorder())),
      SizedBox(height: 16), Text('شنو نتا ؟', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      RadioListTile(value: 'customer', groupValue: role, onChanged: (v) => setState(() => role = v.toString()), title: Text('زبون')),
      RadioListTile(value: 'restaurant', groupValue: role, onChanged: (v) => setState(() => role = v.toString()), title: Text('صاحب مطعم')),
      RadioListTile(value: 'driver', groupValue: role, onChanged: (v) => setState(() => role = v.toString()), title: Text('موصل')),
      if (err != '') Text(err, style: TextStyle(color: Colors.red)),
      SizedBox(height: 12),
      loading ? CircularProgressIndicator() : ElevatedButton(onPressed: register, style: ElevatedButton.styleFrom(backgroundColor: Colors.orange, minimumSize: Size(double.infinity, 50)), child: Text('تسجيل', style: TextStyle(color: Colors.white, fontSize: 18))),
    ])));
  }
}

class CustomerHome extends StatefulWidget { @override _CustomerHomeState createState() => _CustomerHomeState(); }
class _CustomerHomeState extends State<CustomerHome> {
  List<Map<String, dynamic>> cart = [];
  void addToCart(Map<String, dynamic> meal) { setState(() { cart.add(meal); }); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${meal['name']} - تزادت للسلة'))); }
  double get total => cart.fold(0, (sum, e) => sum + (e['price'] as num).toDouble());
  void order() async {
    if (cart.isEmpty) return;
    await FirebaseFirestore.instance.collection('orders').add({'items': cart, 'total': total, 'customerEmail': FirebaseAuth.instance.currentUser!.email, 'status': 'جديد', 'createdAt': FieldValue.serverTimestamp()});
    setState(() => cart.clear());
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('طلبك وصل - غادي يوصلك الموصل')));
  }
  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('قائمة المطاعم'), backgroundColor: Colors.orange, actions: [
        IconButton(icon: Icon(Icons.shopping_cart), onPressed: () {
          showDialog(context: context, builder: (_) => AlertDialog(
            title: Text('السلة - ${cart.length} - المجموع: $total درهم'),
            content: Column(mainAxisSize: MainAxisSize.min, children: cart.map((e) => ListTile(title: Text(e['name']), trailing: Text('${e['price']} د.م'))).toList()),
            actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text('اغلاق')), ElevatedButton(onPressed: () { Navigator.pop(context); order(); }, child: Text('اطلب دابا'))],
          ));
        }),
        IconButton(icon: Icon(Icons.logout), onPressed: () => FirebaseAuth.instance.signOut())
      ]),
      body: StreamBuilder<QuerySnapshot>(stream: FirebaseFirestore.instance.collection('meals').snapshots(), builder: (context, snap) {
        if (!snap.hasData) return Center(child: CircularProgressIndicator());
        if (snap.data!.docs.isEmpty) return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text('باقي ما كاين حتى وجبة', style: TextStyle(fontSize: 20)), SizedBox(height: 10), Text('صاحب المطعم - خصو يزيد وجبات')]));
        return ListView(
          children: snap.data!.docs.map((doc) {
            var d = doc.data() as Map<String, dynamic>;
            return Card(margin: EdgeInsets.all(10), child: ListTile(title: Text(d['name'] ?? '', style: TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('${d['restaurant'] ?? ''} - ${d['price']} درهم'), trailing: ElevatedButton(onPressed: () => addToCart({'name': d['name'], 'price': d['price']}), style: ElevatedButton.styleFrom(backgroundColor: Colors.orange), child: Text('اضف', style: TextStyle(color: Colors.white)))));
          }).toList(),
        );
      }),
    );
  }
}

class RestaurantHome extends StatelessWidget {
  final nameCtrl = TextEditingController(); final priceCtrl = TextEditingController();
  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('صاحب مطعم'), backgroundColor: Colors.orange, actions: [IconButton(icon: Icon(Icons.logout), onPressed: () => FirebaseAuth.instance.signOut())]),
      body: Column(children: [
        Padding(padding: EdgeInsets.all(16), child: Column(children: [
          Text('زيد وجبة جديدة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          SizedBox(height: 10),
          TextField(controller: nameCtrl, decoration: InputDecoration(labelText: 'اسم الوجبة - مثلا طاجين', border: OutlineInputBorder())),
          SizedBox(height: 10),
          TextField(controller: priceCtrl, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'الثمن - مثلا 50', border: OutlineInputBorder())),
          SizedBox(height: 10),
          ElevatedButton(onPressed: () async { if (nameCtrl.text.isEmpty) return; await FirebaseFirestore.instance.collection('meals').add({'name': nameCtrl.text.trim(), 'price': int.tryParse(priceCtrl.text) ?? 0, 'restaurant': FirebaseAuth.instance.currentUser!.email, 'createdAt': FieldValue.serverTimestamp()}); nameCtrl.clear(); priceCtrl.clear(); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تزادت'))); }, style: ElevatedButton.styleFrom(backgroundColor: Colors.orange, minimumSize: Size(double.infinity, 50)), child: Text('زيد الوجبة', style: TextStyle(color: Colors.white))),
        ])),
        Divider(), Text('الطلبات اللي جاوك', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        Expanded(child: StreamBuilder<QuerySnapshot>(stream: FirebaseFirestore.instance.collection('orders').orderBy('createdAt', descending: true).snapshots(), builder: (context, snap) {
          if (!snap.hasData) return Center(child: CircularProgressIndicator());
          if (snap.data!.docs.isEmpty) return Center(child: Text('باقي ما كاين حتى طلب'));
          return ListView(
            children: snap.data!.docs.map((doc) {
              var d = doc.data() as Map<String, dynamic>;
              return Card(margin: EdgeInsets.all(8), child: ListTile(title: Text('طلب - ${d['total']} درهم'), subtitle: Text('${d['customerEmail']} - ${d['status']}'), trailing: Text('${(d['items'] as List).length} وجبات')));
            }).toList(),
          );
        })),
      ]),
    );
  }
}

class DriverHome extends StatelessWidget {
  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('الموصل'), backgroundColor: Colors.green, actions: [IconButton(icon: Icon(Icons.logout), onPressed: () => FirebaseAuth.instance.signOut())]),
      body: StreamBuilder<QuerySnapshot>(stream: FirebaseFirestore.instance.collection('orders').orderBy('createdAt', descending: true).snapshots(), builder: (context, snap) {
        if (!snap.hasData) return Center(child: CircularProgressIndicator());
        if (snap.data!.docs.isEmpty) return Center(child: Text('ما كاين حتى طلب - تسنى شوية'));
        return ListView(
          children: snap.data!.docs.map((doc) {
            var d = doc.data() as Map<String, dynamic>;
            return Card(margin: EdgeInsets.all(10), child: Padding(padding: EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('طلب - ${d['total']} درهم', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              Text('زبون: ${d['customerEmail']}'),
              Text('الحالة: ${d['status']}'),
              SizedBox(height: 8),
              Row(children: [
                ElevatedButton(onPressed: () => FirebaseFirestore.instance.collection('orders').doc(doc.id).update({'status': 'في الطريق'}), child: Text('قبول - في الطريق')),
                SizedBox(width: 8),
                ElevatedButton(onPressed: () => FirebaseFirestore.instance.collection('orders').doc(doc.id).update({'status': 'تم التوصيل'}), style: ElevatedButton.styleFrom(backgroundColor: Colors.green), child: Text('تم التوصيل', style: TextStyle(color: Colors.white))),
              ])
            ])));
          }).toList(),
        );
      }),
    );
  }
}