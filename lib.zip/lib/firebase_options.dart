import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        return web;
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyAZ3az71ARBelPBnwT93Aqjy6Q22Wa8n8U',
    appId: '1:252782274438:web:523d8932be6e5f4cc3ae07',
    messagingSenderId: '252782274438',
    projectId: 'its-ready-pro',
    authDomain: 'its-ready-pro.firebaseapp.com',
    storageBucket: 'its-ready-pro.firebasestorage.app',
    measurementId: 'G-S39JKS5VQC',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAZ3az71ARBelPBnwT93Aqjy6Q22Wa8n8U',
    appId: '1:252782274438:web:523d8932be6e5f4cc3ae07',
    messagingSenderId: '252782274438',
    projectId: 'its-ready-pro',
    storageBucket: 'its-ready-pro.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyAZ3az71ARBelPBnwT93Aqjy6Q22Wa8n8U',
    appId: '1:252782274438:web:523d8932be6e5f4cc3ae07',
    messagingSenderId: '252782274438',
    projectId: 'its-ready-pro',
    storageBucket: 'its-ready-pro.firebasestorage.app',
  );
}